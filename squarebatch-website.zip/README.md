# SquareBatch — Darkroom Photography Squaring Tool

Created by Alex Brijo Sebastian

## How to Deploy

1. **Cloudflare Pages / Netlify**:
   - Drag and drop this extracted folder directly into Cloudflare Pages or Netlify Drop.
   - No build step, no npm install, no backend needed.

2. **GitHub Pages**:
   - Push these files to a GitHub repository.
   - Go to Settings > Pages > Deploy from branch (main / root).

3. **Local Testing**:
   - Double-click index.html or run: npx serve .
